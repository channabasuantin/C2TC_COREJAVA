package com.bus.Repository;

import java.time.LocalDate;
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bus.model.Bus;
 
@Repository
public interface BusRepository extends JpaRepository<Bus, Long> {
 
	List<Bus> findBySourceAndDestination(String source, String destination);
 
	void save(List<Bus> train);
 
	List<Bus> findBySourceAndDestinationAndJourneyDate(String source, String destination, LocalDate journeyDate);
 
 
}