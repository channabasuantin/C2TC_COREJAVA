package com.bus.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bus.Repository.BookingRepository;
import com.bus.Repository.PassengerDetailsRepository;
import com.bus.Repository.PassengerRepository;
import com.bus.Repository.TicketRepository;
import com.bus.Repository.BusRepository;
import com.bus.Repository.UserRepository;
import com.bus.model.Booking;
import com.bus.model.Bus;
import com.bus.model.Passenger;
import com.bus.model.PassengerDetails;
import com.bus.model.Ticket;

@Service
public class TicketService {

	@Autowired
	private TicketRepository ticketRepository;

	@Autowired
	private BookingRepository bookingRepository;

	@Autowired
	private PassengerRepository passengerRepository;

	@Autowired
	PassengerService passengerService;

	@Autowired
	PassengerDetailsRepository passengerDetailsRepository;

	@Autowired
	BusRepository busRepository;

	@Autowired
	UserRepository userRepository;

	public List<Ticket> getAllTickets() {

		return ticketRepository.findAll();
	}

	public List<Booking> findByUserIdAndBookingId(Long userId, Long bookingId) {
		// TODO Auto-generated method stub
		return bookingRepository.findByUserIdAndBookingId(userId, bookingId);
	}

	public void deleteTicketByBookingId(Long bookingId) {
		// TODO Auto-generated method stub
		List<Ticket> tickets = ticketRepository.findByBooking_BookingId(bookingId);

		Booking booking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException("Booking not found"));

		Bus bus = booking.getBus();
		bus.setAvailableSeats(bus.getAvailableSeats() + booking.getTotalTickets());

		busRepository.save(bus);
		for (Ticket ticket : tickets) {
			ticketRepository.delete(ticket);
		}

	}

	public Ticket createTicket(Long bookingId) {
		// Fetch the booking using the bookingId
		Booking booking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException("Booking not found"));

		// Create a new ticket
		Ticket ticket = new Ticket();
		ticket.setBooking(booking);
		ticket.setStatus("Reserved");

		// Save the ticket
		ticket = ticketRepository.save(ticket);

		List<Passenger> passengers = passengerRepository.findByBooking(booking);

		// Adjust the available tickets for the bus
		Bus bus = booking.getBus();
		bus.setAvailableSeats(bus.getAvailableSeats() - passengers.size());
		busRepository.save(bus);

		// Set the ticket for each passenger detail
		for (Passenger passenger : passengers) {

			PassengerDetails details = new PassengerDetails();
			details.setBooking(booking);
			details.setAge(passenger.getAge());
			details.setName(passenger.getName());
			details.setGender(passenger.getGender());
			passengerDetailsRepository.save(details);

			passengerRepository.delete(passenger);
		}

		return ticket;
	}

}
