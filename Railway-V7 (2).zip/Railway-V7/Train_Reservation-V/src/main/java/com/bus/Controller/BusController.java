package com.bus.Controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bus.Exception.BusException;
import com.bus.Service.BusService;
import com.bus.model.Bus;

 
@RestController
@RequestMapping("/bus")
@CrossOrigin(origins = "*")
public class BusController {
 
	@Autowired
	private BusService busService;
 
	@PostMapping("/add")
 
	public Bus saveBus(@RequestBody Bus bus) {
		return busService.saveBus(bus);
	}
 
	@PutMapping("/update")
	public Bus updateBus(@RequestBody Bus bus) {
		return busService.updateBus(bus);
	}
 
	@GetMapping("/all")
	public List<Bus> getAllBuses() throws BusException {
		return busService.getAllBuses();
	}
 
	@GetMapping("/{id}")
	public Optional<Bus> getBusById(@PathVariable Long id) throws BusException {
		return busService.getBusById(id);
	}
 
	@GetMapping("/{source}/{destination}")
	public List<Bus> getBusesBySourceAndDestination(@PathVariable String source, @PathVariable String destination)
			throws BusException {
		return busService.getBusesBySourceAndDestination(source, destination);
	}
 
	@GetMapping("/{source}/{destination}/{journeyDate}")
	public List<Bus> getBusesBySourceAndDestinationAndJourneyDate(@PathVariable String source,
			@PathVariable String destination, @PathVariable LocalDate journeyDate) throws BusException {
		return busService.getBusesBySourceAndDestinationAndJourneyDate(source, destination, journeyDate);
	}
 
	@DeleteMapping("/delete/{id}")
	public void deleteBus(@PathVariable Long id) throws BusException {
		busService.deleteBus(id);
	}
}