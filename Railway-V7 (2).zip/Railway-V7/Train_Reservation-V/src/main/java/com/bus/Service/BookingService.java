package com.bus.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.bus.Exception.ThrowValidException;
import com.bus.Repository.BookingRepository;
import com.bus.Repository.PassengerDetailsRepository;
import com.bus.Repository.PassengerRepository;
import com.bus.Repository.TicketRepository;
import com.bus.Repository.BusRepository;
import com.bus.Repository.UserRepository;
import com.bus.model.Booking;
import com.bus.model.Bus;
import com.bus.model.Passenger;
import com.bus.model.User;

import jakarta.transaction.Transactional;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Autowired
	private PassengerRepository passengerRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BusRepository busRepository;

	@Autowired
	private PassengerService passengerService;

	@Autowired
	PassengerDetailsRepository detailsRepository;

	@Autowired
	TicketRepository ticketRepository;

	public List<Booking> getAllBookings() {
		return (List<Booking>) bookingRepository.findAll();
	}

	public List<Passenger> findPassengersByBookingId(Long bookingId) throws NotFoundException {
		Optional<Booking> bookingOptional = bookingRepository.findById(bookingId);
		if (bookingOptional.isPresent()) {
			Booking booking = bookingOptional.get();
			return passengerRepository.findByBooking(booking);
		} else {
			throw new NotFoundException();
		}
	}

	public Booking retrieveBookingById(Long bookingId) {
		try {
			Booking booking = bookingRepository.findById(bookingId).get();
			List<Passenger> passengers = passengerRepository.findByBooking(booking);
			return booking;
		} catch (Exception e) {
			throw new ThrowValidException("Wrong order id:" + bookingId);
		}
	}

	@Transactional
	public Booking createBooking(Long busId, Long userId, List<Passenger> passengers) throws NotFoundException {

		// Get the bus and user objects from the database
		Bus bus = busRepository.findById(busId).orElseThrow(() -> new RuntimeException("Bus not found"));
		User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

		// Create a new booking object
		Booking booking = new Booking();
		booking.setUser(user);
		booking.setBus(bus);

		// Calculate the total fare
		int totalFare = passengers.size() * bus.getFare();
		booking.setTotalFare(totalFare);

		Integer totalSeats = passengers.size();
		booking.setTotalTickets(totalSeats);
		
		booking = bookingRepository.save(booking);

		// Set the booking ID for each passenger
		for (Passenger passenger : passengers) {
			passenger.setBooking(booking);
			passenger.setUser(user);
			passenger.setBus(bus);
			passengerRepository.save(passenger);

		}

		return booking;
	}

	public void deleteBookingById(Long bookingId) {
		Booking booking = bookingRepository.findById(bookingId)
				.orElseThrow(() -> new RuntimeException("Booking not found"));

		List<Passenger> passengers = passengerRepository.findByBooking(booking);
		Bus bus = booking.getBus();
		bus.setAvailableSeats(bus.getAvailableSeats() + booking.getTotalTickets());
		busRepository.save(bus);

		bookingRepository.delete(booking);
	}

	public void deleteAllBookings() {
		bookingRepository.deleteAll();
	}

	public List<Booking> retrieveBookingUserById(Long userId) {
		// TODO Auto-generated method stub
		Optional<User> user = userRepository.findById(userId);
		return bookingRepository.findByUser(user.get());

	}

}