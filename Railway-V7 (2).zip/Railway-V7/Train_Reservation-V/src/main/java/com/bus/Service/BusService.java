package com.bus.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bus.Exception.BusException;
import com.bus.Repository.BusRepository;
import com.bus.model.Bus;

@Service
public class BusService {
 
	@Autowired
	private BusRepository busRepo;
 
	public List<Bus> getAllBuses() throws BusException {
		List<Bus> buses = busRepo.findAll();
		if (buses.isEmpty()) {
			throw new BusException("No buses found in the database");
		}
 
		return buses;
	}
 
	public Optional<Bus> getBusById(Long id) throws BusException {
		Optional<Bus> existingBus = busRepo.findById(id);
		if (!existingBus.isPresent()) {
			throw new BusException("No bus exist with this busId: " + id);
		}
 
		return existingBus;
	}
 
	public List<Bus> getBusesBySourceAndDestination(String source, String destination) throws BusException {
		List<Bus> buses = busRepo.findBySourceAndDestination(source, destination);
		if (buses.isEmpty()) {
			throw new BusException("No buses found with the given Source and Destination");
		}
 
		return buses;
 
	}
 
	public List<Bus> getBusesBySourceAndDestinationAndJourneyDate(String source, String destination,
			LocalDate journeyDate) throws BusException {
 
		List<Bus> buses = busRepo.findBySourceAndDestinationAndJourneyDate(source, destination,
				journeyDate);
		if (buses.isEmpty()) {
			throw new BusException("No buses found with the given Source, Destination and Date");
		}
 
		return buses;
 
	}
 
	public Bus saveBus(Bus bus) {
		return busRepo.save(bus);
	}
 
	public Bus updateBus(Bus bus) {
		return busRepo.save(bus);
	}
 
	public Bus deleteBus(Long id) throws BusException {
		Bus bus = busRepo.findById(id).orElseThrow(() -> new BusException("Bus not found for delete Bus record"));
		// Delete the bus from the database
		busRepo.delete(bus);
 
		return bus;
	}
 
}
