package com.bus.Exception;



public class BusException extends Exception {
 
	    public BusException(){
	    	
	    }
	    public BusException(String msg)
	    {
	    	super(msg);
	    }
	
}