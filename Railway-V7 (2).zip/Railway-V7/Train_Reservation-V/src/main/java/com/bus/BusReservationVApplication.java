package com.bus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusReservationVApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusReservationVApplication.class, args);
	}

}
