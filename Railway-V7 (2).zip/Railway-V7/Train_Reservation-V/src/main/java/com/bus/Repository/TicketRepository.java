package com.bus.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bus.model.Bus;
import com.bus.model.Passenger;
import com.bus.model.Ticket;
import com.bus.model.User;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {

	void save(Passenger passenger);

	void save(Bus bus);

	void save(User user);

	List<Ticket> findByBooking_BookingId(Long bookingId);

}
